//Dios que taller tan hptamente esquizofrenico
//viva venezuela
//Majo se tirara diferencial otra vez
//A samu le robaron xdddd
//Samu si llegas a leer esto te robaron por cachon

package uniandes.dpoo.taller7.interfaz4;

import com.formdev.flatlaf.FlatLightLaf;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JDialog;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.List;

public class VentanaPrincipal extends JFrame {
    private PanelTablero panelTablero;
    private PanelSuperior panelSuperior;
    private PanelInferior panelInferior;
    private PanelDerecho panelDerecho;
    private int tama�oActual;
    private RegistroTop10 registroTop10;

    public VentanaPrincipal() {
        setTitle("Lights Out");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        setLayout(new BorderLayout());

        panelSuperior = new PanelSuperior();
        panelDerecho = new PanelDerecho();
        panelInferior = new PanelInferior();
        panelTablero = new PanelTablero(5);
        tama�oActual = 5;
        registroTop10 = new RegistroTop10();

        add(panelSuperior, BorderLayout.NORTH);
        add(panelDerecho, BorderLayout.EAST);
        add(panelInferior, BorderLayout.SOUTH);
        add(panelTablero, BorderLayout.CENTER);

        panelTablero.setActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if ("Ganador".equals(e.getActionCommand())) {
                    registrarPuntaje();
                } else {
                    panelInferior.incrementarJugadas();
                }
            }
        });

        panelSuperior.getComboTama�o().addActionListener(e -> cambiarTama�oTablero());

        panelDerecho.getBotonNuevo().addActionListener(e -> crearNuevoJuego());
        panelDerecho.getBotonReiniciar().addActionListener(e -> reiniciarJuego());
        panelDerecho.getBotonTop10().addActionListener(e -> mostrarTop10());
        panelDerecho.getBotonCambiarJugador().addActionListener(e -> cambiarJugador());


        setButtonStyles(panelDerecho.getBotonNuevo());
        setButtonStyles(panelDerecho.getBotonReiniciar());
        setButtonStyles(panelDerecho.getBotonTop10());
        setButtonStyles(panelDerecho.getBotonCambiarJugador());

        // puntajes de prueba porque me da pereza jugar esta vaina muchas veces
        agregarPuntajesDePrueba();
    }

    private void setButtonStyles(JButton button) {
        button.setBackground(Color.LIGHT_GRAY);
        button.setFont(new Font("Arial", Font.BOLD, 12));
    }

    private void agregarPuntajesDePrueba() {
        registroTop10.agregarPuntaje("Santi", 10);
        registroTop10.agregarPuntaje("Nano", 20);
        registroTop10.agregarPuntaje("Majo", 15);
        registroTop10.agregarPuntaje("Samu", 25);
        registroTop10.agregarPuntaje("Chamo", 5);
        registroTop10.agregarPuntaje("HugoBoss", 30);
        registroTop10.agregarPuntaje("Perro", 35);
        registroTop10.agregarPuntaje("Diomedez", 12);
        registroTop10.agregarPuntaje("Frozono", 8);
        registroTop10.agregarPuntaje("Antropologa", 40);
        registroTop10.agregarPuntaje("Santihijodeleche", 18); //lo se soy flojo
    }

    private void crearNuevoJuego() {
        tama�oActual = obtenerTama�oTablero();
        String dificultad = panelSuperior.getDificultadSeleccionada();
   

        remove(panelTablero);
        panelTablero = new PanelTablero(tama�oActual);
        panelTablero.setActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if ("Ganador".equals(e.getActionCommand())) {
                    registrarPuntaje();
                } else {
                    panelInferior.incrementarJugadas();
                }
            }
        });
        add(panelTablero, BorderLayout.CENTER);
        revalidate();
        repaint();
        panelInferior.resetJugadas(); // resetear a 0
    }

    private void cambiarTama�oTablero() {
        int tama�o = obtenerTama�oTablero();
        panelTablero.setTama�o(tama�o);
        panelTablero.revalidate();
        panelTablero.repaint();
    }

    private void reiniciarJuego() {
        remove(panelTablero);
        panelTablero = new PanelTablero(tama�oActual);
        panelTablero.setActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if ("Ganador".equals(e.getActionCommand())) {
                    registrarPuntaje();
                } else {
                    panelInferior.incrementarJugadas();
                }
            }
        });
        add(panelTablero, BorderLayout.CENTER);
        revalidate();
        repaint();
        panelInferior.resetJugadas(); 
    }

    private void registrarPuntaje() {
        String nombreJugador = panelInferior.getCampoJugador().getText();
        int jugadas = Integer.parseInt(panelInferior.getCampoJugadas().getText());
        registroTop10.agregarPuntaje(nombreJugador, jugadas);
        JOptionPane.showMessageDialog(this, "�Has ganado! Puntaje registrado: " + jugadas, "Ganador", JOptionPane.INFORMATION_MESSAGE);
    }

    private void mostrarTop10() {
        List<Puntaje> top10 = registroTop10.getTop10();
        Top10 top10Dialog = new Top10(this, top10);
        top10Dialog.setVisible(true);
    }

    private void cambiarJugador() {
        String nuevoJugador = JOptionPane.showInputDialog(this, "Ingrese el nombre del nuevo jugador:", "Cambiar Jugador", JOptionPane.PLAIN_MESSAGE);
        if (nuevoJugador != null && !nuevoJugador.trim().isEmpty()) {
            panelInferior.getCampoJugador().setText(nuevoJugador);
        }
    }

    private int obtenerTama�oTablero() {
        String tama�oSeleccionado = (String) panelSuperior.getComboTama�o().getSelectedItem();
        switch (tama�oSeleccionado) {
            case "6x6":
                return 6;
            case "7x7":
                return 7;
            case "5x5":
            default:
                return 5;
        }
    }

    public static void main(String[] args) {
        FlatLightLaf.install();
        VentanaPrincipal ventana = new VentanaPrincipal();
        ventana.setVisible(true);
    }
}






