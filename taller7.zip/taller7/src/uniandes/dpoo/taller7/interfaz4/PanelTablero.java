package uniandes.dpoo.taller7.interfaz4;

import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class PanelTablero extends JPanel {
    private int tama�o;
    private boolean[][] luces;
    private ActionListener listener;

    public PanelTablero(int tama�o) {
        this.tama�o = tama�o;
        luces = new boolean[tama�o][tama�o];
        inicializarLuces();

        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                int x = e.getX();
                int y = e.getY();
                int fila = y / (getHeight() / tama�o);
                int columna = x / (getWidth() / tama�o);
                alternarEstado(fila, columna);
                repaint();
                if (listener != null) {
                    listener.actionPerformed(new ActionEvent(this, ActionEvent.ACTION_PERFORMED, null));
                }
                if (verificarGanador()) {
                    if (listener != null) {
                        listener.actionPerformed(new ActionEvent(this, ActionEvent.ACTION_PERFORMED, "Ganador"));
                    }
                }
            }
        });
    }

    public void setTama�o(int tama�o) {
        this.tama�o = tama�o;
        luces = new boolean[tama�o][tama�o];
        inicializarLuces();
        repaint();
    }

    public void setActionListener(ActionListener listener) {
        this.listener = listener;
    }

    private void inicializarLuces() {
        for (int i = 0; i < tama�o; i++) {
            for (int j = 0; j < tama�o; j++) {
                luces[i][j] = true; // cuadros iluminados :p
            }
        }
    }

    private void alternarEstado(int fila, int columna) {
        if (fila >= 0 && fila < tama�o && columna >= 0 && columna < tama�o) {
            luces[fila][columna] = !luces[fila][columna];
            if (fila > 0) luces[fila-1][columna] = !luces[fila-1][columna];
            if (fila < tama�o - 1) luces[fila+1][columna] = !luces[fila+1][columna];
            if (columna > 0) luces[fila][columna-1] = !luces[fila][columna-1];
            if (columna < tama�o - 1) luces[fila][columna+1] = !luces[fila][columna+1];
        }
    }

    private boolean verificarGanador() {
        for (int i = 0; i < tama�o; i++) {
            for (int j = 0; j < tama�o; j++) {
                if (luces[i][j]) {
                    return false; // Si algun cuadro esta prendido aun no acaba osea el jugador es muy malo :p
                }
            }
        }
        return true; // Todos los cuadros tan apagados gana, que pro
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        int width = getWidth() / tama�o;
        int height = getHeight() / tama�o;

        for (int i = 0; i < tama�o; i++) {
            for (int j = 0; j < tama�o; j++) {
                Color color1 = luces[i][j] ? new Color(173, 255, 47) : new Color(0, 0, 139);
                Color color2 = luces[i][j] ? new Color(0, 100, 0) : new Color(25, 25, 112);
                GradientPaint gp = new GradientPaint(j * width, i * height, color1, (j + 1) * width, (i + 1) * height, color2);
                g2d.setPaint(gp);
                g2d.fillRect(j * width, i * height, width, height);
                g2d.setColor(Color.BLACK);
                g2d.drawRect(j * width, i * height, width, height);
            }
        }
    }
}




