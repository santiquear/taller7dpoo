package uniandes.dpoo.taller7.interfaz4;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class RegistroTop10 {
    private List<Puntaje> puntajes;

    public RegistroTop10() {
        puntajes = new ArrayList<>();
    }

    public void agregarPuntaje(String nombre, int puntaje) {
        puntajes.add(new Puntaje(nombre, puntaje));
        Collections.sort(puntajes);
        if (puntajes.size() > 10) {
            puntajes.remove(puntajes.size() - 1); // solo el top 10
        }
    }

    public List<Puntaje> getTop10() {
        return puntajes;
    }
}

//disclaimer creo que hice muchas clases pero nah asi sirve
