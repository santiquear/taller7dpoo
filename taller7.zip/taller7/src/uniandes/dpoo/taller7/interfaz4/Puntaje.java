package uniandes.dpoo.taller7.interfaz4;

public class Puntaje implements Comparable<Puntaje> {
    private String nombre;
    private int puntaje;

    public Puntaje(String nombre, int puntaje) {
        this.nombre = nombre;
        this.puntaje = puntaje;
    }

    public String getNombre() {
        return nombre;
    }

    public int getPuntaje() {
        return puntaje;
    }

    @Override
    public int compareTo(Puntaje otro) {
        return Integer.compare(otro.getPuntaje(), this.puntaje); // Ordenar de mayor a menor osea de mejor puntaje a peor para
        													     //los que no entienden inglish
    }
}
