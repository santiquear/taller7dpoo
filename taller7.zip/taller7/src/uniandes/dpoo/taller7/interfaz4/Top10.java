package uniandes.dpoo.taller7.interfaz4;
import javax.swing.JFrame;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.DefaultListModel;
import java.awt.BorderLayout;
import java.util.List;

public class Top10 extends JDialog {
    public Top10(JFrame parent, List<Puntaje> puntajes) {
        super(parent, "Top 10 de Puntajes", true);
        setSize(400, 300);
        setLocationRelativeTo(parent);

        DefaultListModel<Puntaje> listModel = new DefaultListModel<>();
        for (Puntaje puntaje : puntajes) {
            listModel.addElement(puntaje);
        }

        JList<Puntaje> list = new JList<>(listModel);
        list.setCellRenderer(new Top10perso());
        JScrollPane scrollPane = new JScrollPane(list);

        JPanel panel = new JPanel(new BorderLayout());
        panel.add(scrollPane, BorderLayout.CENTER);

        add(panel);
    }
}

