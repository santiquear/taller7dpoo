package uniandes.dpoo.taller7.interfaz4;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.ListCellRenderer;
import javax.swing.BorderFactory;
import javax.swing.JList;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;

public class Top10perso extends JPanel implements ListCellRenderer<Puntaje> {
    private JLabel lblPosicion;
    private JLabel lblNombre;
    private JLabel lblPuntaje;

    public Top10perso() {
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;

        lblPosicion = new JLabel();
        lblNombre = new JLabel();
        lblPuntaje = new JLabel();

        lblPosicion.setFont(new Font("Arial", Font.BOLD, 18));
        lblNombre.setFont(new Font("Arial", Font.BOLD, 18));
        lblPuntaje.setFont(new Font("Arial", Font.BOLD, 18));

        gbc.gridx = 0;
        gbc.gridy = 0;
        add(lblPosicion, gbc);

        gbc.gridx = 1;
        gbc.insets.left = 10; 
        add(lblNombre, gbc);

        gbc.gridx = 2;
        gbc.insets.left = 10; 
        add(lblPuntaje, gbc);

        setBorder(BorderFactory.createLineBorder(Color.BLACK));
    }

    @Override
    public Component getListCellRendererComponent(JList<? extends Puntaje> list, Puntaje value, int index, boolean isSelected, boolean cellHasFocus) {
        lblPosicion.setText((index + 1) + ". ");
        lblNombre.setText(value.getNombre());
        lblPuntaje.setText(String.valueOf(value.getPuntaje()));

        if (isSelected) {
            setBackground(list.getSelectionBackground());
            setForeground(list.getSelectionForeground());
        } else {
            setBackground(list.getBackground());
            setForeground(list.getForeground());
        }

        // colores para los 3 lugares :)
        switch (index) {
            case 0:
                setBackground(new Color(255, 215, 0)); // Oro :D
                break;
            case 1:
                setBackground(new Color(192, 192, 192)); // Plata :0
                break;
            case 2:
                setBackground(new Color(205, 127, 50)); // Bronce :(
                break;
            default:
                setBackground(Color.WHITE);
                break;
        }

        return this;
    }
}

