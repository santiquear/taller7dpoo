package uniandes.dpoo.taller7.interfaz4;

import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.BoxLayout;
import javax.swing.Box;
import java.awt.Dimension;

public class PanelDerecho extends JPanel {
    private JButton botonNuevo;
    private JButton botonReiniciar;
    private JButton botonTop10;
    private JButton botonCambiarJugador;

    public PanelDerecho() {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        botonNuevo = new JButton("NUEVO");
        botonReiniciar = new JButton("REINICIAR");
        botonTop10 = new JButton("TOP-10");
        botonCambiarJugador = new JButton("CAMBIAR JUGADOR");

        Dimension buttonSize = new Dimension(120, 40);
        botonNuevo.setPreferredSize(buttonSize);
        botonNuevo.setMaximumSize(buttonSize);
        botonNuevo.setAlignmentX(CENTER_ALIGNMENT);

        botonReiniciar.setPreferredSize(buttonSize);
        botonReiniciar.setMaximumSize(buttonSize);
        botonReiniciar.setAlignmentX(CENTER_ALIGNMENT);

        botonTop10.setPreferredSize(buttonSize);
        botonTop10.setMaximumSize(buttonSize);
        botonTop10.setAlignmentX(CENTER_ALIGNMENT);

        botonCambiarJugador.setPreferredSize(buttonSize);
        botonCambiarJugador.setMaximumSize(buttonSize);
        botonCambiarJugador.setAlignmentX(CENTER_ALIGNMENT);

        add(Box.createVerticalGlue());
        add(botonNuevo);
        add(Box.createVerticalStrut(10));
        add(botonReiniciar);
        add(Box.createVerticalStrut(10));
        add(botonTop10);
        add(Box.createVerticalStrut(10));
        add(botonCambiarJugador);
        add(Box.createVerticalGlue());
    }

    public JButton getBotonNuevo() {
        return botonNuevo;
    }

    public JButton getBotonReiniciar() {
        return botonReiniciar;
    }

    public JButton getBotonTop10() {
        return botonTop10;
    }

    public JButton getBotonCambiarJugador() {
        return botonCambiarJugador;
    }
}

