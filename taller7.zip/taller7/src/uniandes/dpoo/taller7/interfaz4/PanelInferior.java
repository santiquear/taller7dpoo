package uniandes.dpoo.taller7.interfaz4;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.GridLayout;

public class PanelInferior extends JPanel {
    private JTextField campoJugadas;
    private JTextField campoJugador;

    public PanelInferior() {
        setLayout(new GridLayout(1, 4));

        JLabel etiquetaJugadas = new JLabel("Jugadas:");
        campoJugadas = new JTextField(5);
        campoJugadas.setEditable(false);
        campoJugadas.setText("0"); // inicia siempre en 0 obviiii

        JLabel etiquetaJugador = new JLabel("Jugador:");
        campoJugador = new JTextField(10);

        add(etiquetaJugadas);
        add(campoJugadas);
        add(etiquetaJugador);
        add(campoJugador);
    }

    public JTextField getCampoJugadas() {
        return campoJugadas;
    }

    public JTextField getCampoJugador() {
        return campoJugador;
    }

    public void resetJugadas() {
        campoJugadas.setText("0");
    }

    public void incrementarJugadas() {
        String textoJugadas = campoJugadas.getText();
        int jugadas = 0;
        if (!textoJugadas.isEmpty()) {
            try {
                jugadas = Integer.parseInt(textoJugadas);
            } catch (NumberFormatException e) {
                jugadas = 0; // por si falla vuelve a 0 :)
            }
        }
        campoJugadas.setText(String.valueOf(jugadas + 1));
    }
}
