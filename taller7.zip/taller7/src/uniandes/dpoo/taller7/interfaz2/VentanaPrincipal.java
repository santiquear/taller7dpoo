package uniandes.dpoo.taller7.interfaz2;

import javax.swing.JFrame;
import java.awt.BorderLayout;

public class VentanaPrincipal extends JFrame {
    public VentanaPrincipal() {
        setTitle("Luces fuera :D");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        setLayout(new BorderLayout());

        PanelSuperior panelSuperior = new PanelSuperior();
        PanelDerecho panelDerecho = new PanelDerecho();
        PanelInferior panelInferior = new PanelInferior();

        add(panelSuperior, BorderLayout.NORTH);
        add(panelDerecho, BorderLayout.EAST);
        add(panelInferior, BorderLayout.SOUTH);
    }

    public static void main(String[] args) {
        VentanaPrincipal ventana = new VentanaPrincipal();
        ventana.setVisible(true);
    }
}