package uniandes.dpoo.taller7.interfaz3;

import javax.swing.JFrame;
import javax.swing.JComboBox;
import java.awt.BorderLayout;

public class VentanaPrincipal extends JFrame {
    private PanelTablero panelTablero;
    private PanelSuperior panelSuperior;

    public VentanaPrincipal() {
        setTitle("Luces fuera :D");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        setLayout(new BorderLayout());

        panelSuperior = new PanelSuperior();
        PanelDerecho panelDerecho = new PanelDerecho();
        PanelInferior panelInferior = new PanelInferior();
        panelTablero = new PanelTablero(5);

        add(panelSuperior, BorderLayout.NORTH);
        add(panelDerecho, BorderLayout.EAST);
        add(panelInferior, BorderLayout.SOUTH);
        add(panelTablero, BorderLayout.CENTER);

        JComboBox<String> comboTama�o = (JComboBox<String>) panelSuperior.getComponent(1);
        comboTama�o.addActionListener(e -> cambiarTama�oTablero());
    }

    private void cambiarTama�oTablero() {
        String tama�oSeleccionado = (String) ((JComboBox<?>) panelSuperior.getComponent(1)).getSelectedItem();
        int tama�o = 5;
        switch (tama�oSeleccionado) {
            case "6x6":
                tama�o = 6;
                break;
            case "7x7":
                tama�o = 7;
                break;
            case "5x5":
            default:
                tama�o = 5;
        }
        remove(panelTablero);
        panelTablero = new PanelTablero(tama�o);
        add(panelTablero, BorderLayout.CENTER);
        revalidate();
        repaint();
    }

    public static void main(String[] args) {
        VentanaPrincipal ventana = new VentanaPrincipal();
        ventana.setVisible(true);
    }
}
