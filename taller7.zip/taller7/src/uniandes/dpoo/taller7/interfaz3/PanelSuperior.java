package uniandes.dpoo.taller7.interfaz3;

import javax.swing.JPanel;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import java.awt.GridLayout;

public class PanelSuperior extends JPanel {
    public PanelSuperior() {
        setLayout(new GridLayout(1, 6));

        JLabel etiquetaTama�o = new JLabel("Tama�o:");
        JComboBox<String> comboTama�o = new JComboBox<>(new String[]{"5x5", "6x6", "7x7"});

        JLabel etiquetaDificultad = new JLabel("Dificultad:");
        JRadioButton radioFacil = new JRadioButton("F�cil");
        JRadioButton radioMedio = new JRadioButton("Medio");
        JRadioButton radioDificil = new JRadioButton("Dif�cil");

        ButtonGroup grupoDificultad = new ButtonGroup();
        grupoDificultad.add(radioFacil);
        grupoDificultad.add(radioMedio);
        grupoDificultad.add(radioDificil);

        add(etiquetaTama�o);
        add(comboTama�o);
        add(etiquetaDificultad);
        add(radioFacil);
        add(radioMedio);
        add(radioDificil);
    }
}
