package uniandes.dpoo.taller7.interfaz3;

import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.BoxLayout;
import javax.swing.Box;
import java.awt.Dimension;

public class PanelDerecho extends JPanel {
    public PanelDerecho() {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        JButton botonNuevo = new JButton("NUEVO");
        JButton botonReiniciar = new JButton("REINICIAR");
        JButton botonTop10 = new JButton("TOP-10");
        JButton botonCambiarJugador = new JButton("CAMBIAR JUGADOR");

        Dimension boton = new Dimension(200, 40); 
        botonNuevo.setPreferredSize(boton);
        botonNuevo.setMaximumSize(boton);
        botonNuevo.setAlignmentX(CENTER_ALIGNMENT);

        botonReiniciar.setPreferredSize(boton);
        botonReiniciar.setMaximumSize(boton);
        botonReiniciar.setAlignmentX(CENTER_ALIGNMENT);

        botonTop10.setPreferredSize(boton);
        botonTop10.setMaximumSize(boton);
        botonTop10.setAlignmentX(CENTER_ALIGNMENT);

        botonCambiarJugador.setPreferredSize(boton);
        botonCambiarJugador.setMaximumSize(boton);
        botonCambiarJugador.setAlignmentX(CENTER_ALIGNMENT);

        add(Box.createVerticalGlue()); // centrar los botones de forma vertical
        add(botonNuevo);
        add(Box.createVerticalStrut(10)); //espacio entre botones para que no se vea feo :p
        add(botonReiniciar);
        add(Box.createVerticalStrut(10));
        add(botonTop10);
        add(Box.createVerticalStrut(10));
        add(botonCambiarJugador);
        add(Box.createVerticalGlue());
    }
}

