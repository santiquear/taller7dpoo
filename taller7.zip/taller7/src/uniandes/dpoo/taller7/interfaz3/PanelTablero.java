package uniandes.dpoo.taller7.interfaz3;

import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Color;

public class PanelTablero extends JPanel {
    private int tama�o;

    public PanelTablero(int tama�o) {
        this.tama�o = tama�o;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        int width = getWidth() / tama�o;
        int height = getHeight() / tama�o;

        for (int i = 0; i < tama�o; i++) {
            for (int j = 0; j < tama�o; j++) {
                g2d.setColor(Color.YELLOW);
                g2d.fillRect(j * width, i * height, width, height);
                g2d.setColor(Color.BLACK);
                g2d.drawRect(j * width, i * height, width, height);
            }
        }
    }
}

