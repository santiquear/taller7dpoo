package uniandes.dpoo.taller7.interfaz3;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.GridLayout;

public class PanelInferior extends JPanel {
    public PanelInferior() {
        setLayout(new GridLayout(1, 4));

        JLabel etiquetaJugadas = new JLabel("Jugadas:");
        JTextField campoJugadas = new JTextField(5);
        campoJugadas.setEditable(false);

        JLabel etiquetaJugador = new JLabel("Jugador:");
        JTextField campoJugador = new JTextField(10);

        add(etiquetaJugadas);
        add(campoJugadas);
        add(etiquetaJugador);
        add(campoJugador);
    }
}